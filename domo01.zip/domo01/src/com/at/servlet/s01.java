package com.at.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(value = "/s01")
public class s01 extends HttpServlet {
    ArrayList<String> usernameArr = new ArrayList<>();
    ArrayList<String> passwordArr = new ArrayList<>();
    ArrayList<String> phone_numberArr = new ArrayList<>();
    ArrayList<String> emailArr = new ArrayList<>();
    ArrayList<String> QianMingArr = new ArrayList<>();


    public void insert(String a1, String a2, String a3, String a4, String a5) {
        usernameArr.add(a1);
        passwordArr.add(a2);
        passwordArr.set(usernameArr.size()-1,a2);
        phone_numberArr.add(a3);
        phone_numberArr.set(usernameArr.size()-1,a3);
        emailArr.add(a4);
        emailArr.set(usernameArr.size()-1,a4);
        QianMingArr.add(a5);
        QianMingArr.set(usernameArr.size()-1,a5);

        System.out.println("用户名数组："+usernameArr);
        System.out.println("密码数组："+passwordArr);
        System.out.println("手机号数组："+phone_numberArr);
        System.out.println("邮箱数组："+emailArr);
        System.out.println("签名数组："+QianMingArr);
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("servlet01执行了");
        PrintWriter writer = resp.getWriter();


        //校验传进来的用户名是否已存在于用户名数组中
        if (usernameArr.contains(req.getParameter("ccs1"))) {

            //返回"用户名已存在"
            writer.write("用户名已存在");

        } else {

            //把接收到的参数放入数据库数组
            insert(
                    req.getParameter("ccs1"),
                    req.getParameter("ccs2"),
                    req.getParameter("ccs3"),
                    req.getParameter("ccs4"),
                    req.getParameter("ccs5")
            );

            //返回值："注册成功"
            writer.write("注册成功");

        }






    }
}
