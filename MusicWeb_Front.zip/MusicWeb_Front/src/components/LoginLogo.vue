<template>
    <div class="login-logo">
        <svg class="icon">
            <use xlink:href="#icon-erji"></use>
        </svg>
    </div>
</template>

<script>
    export default {
        name: "LoginLogo"
    }
</script>

<style scoped>
    .login-logo {
        background-color:#2aa3ef;
        height: 100vh;
        width: 50vw;
        min-width: 650px;
        overflow: hidden;
        justify-content: center;
    align-items: center;
    flex-direction: row;
    flex-wrap: nowrap;
        display: flex;
    }
    .icon{
        width: 6.5em;
        height:  6.5em;
        font-size: 6.5em;
        color: #2796dd;
        fill: currentColor;
        overflow: hidden;
        position: relative;
        transform: rotate(-30deg);
    }
</style>
