<template>
    <div class="scroll-top" @click="returnTop">
        <div class="box-in"></div>
    </div>
</template>
<script>
    export default {
        name: 'ScrollTop',
        methods: {
            returnTop() {
                document.documentElement.scrollTop = document.body.scrollTop = 0;
            }
        }
    }
</script>

<style  scoped>
.scroll-top{
    position: fixed;
    width: 50px;
    height: 30px;
    right: 10px;
    bottom: 80px;
    padding-top: 20px;
    text-align: center;
    background-color: white;
    border-radius: 20%;
    overflow: hidden;
    -webkit-box-shadow:0 0 4px 3px rgba(0, 0, 0, 0.2);
    -moz-box-shadow:0 0 4px 3px rgba(0, 0, 0, 0.2);
    box-shadow:0 0 4px 3px rgba(0, 0, 0, 0.2);
}
.scroll-top:hover:before{
    top: 50%;
}
.scroll-top:before{
    content: "顶部";
    position: absolute;
    font-weight: bold;
    width: 30px;
    top: -50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.box-in {
    visibility: visible;
    display: inline-block;
    height: 15px;
    width: 15px;
    border: 1px solid black;
    border-color:  black transparent transparent black;
    transform: rotate(45deg);
}
    .box-in:hover{
        visibility: hidden;
    }
</style>
