<template>
    <div class="the-footer">
        <p>关于 | 帮助 |条款 |反馈</p>
        <p>Copyright ©2021</p>
    </div>
</template>
<script>
    export default {
        name: 'the-footer'
    }
</script>
<style scoped>
    .the-footer {
        width: 100%;
        height: 100px;
        justify-content: center;
        flex-direction: column;
        text-align: center;
        background-color: #e6ecf0;
        padding-top: 40px;
    }

    p {
        height: 30px;
    }
</style>
