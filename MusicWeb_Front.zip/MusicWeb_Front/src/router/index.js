import Vue from 'vue'
import Router from 'vue-router'
import Home from '../pages/Home'
import Mymusic from "../pages/Mymusic";
import Singer from "../pages/Singer";
import SongList from "../pages/SongList";
import Search from "../pages/Search";
import Lyric from "../pages/Lyric";
import LoginIn from "../pages/LoginIn";
import Register from "../pages/Register";
import Setting from "../pages/Setting";
import SingerAlbum from "../pages/SingerAlbum";
import SongListAlbum from "../pages/SongListAlbum";
import RegiSuccess from "../pages/RegiSuccess";
import LogiSuccess from "../pages/LogiSuccess";

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/my-music',
      name: 'my-music',
      component: Mymusic
    },
    {
      path: '/singer',
      name: 'singer',
      component: Singer
    },
    {
      path: '/song-list',
      name: 'song-list',
      component: SongList
    },
    {
      path: '/search',
      name: 'Search',
      component: Search
    },
    {
      path: '/lyric',
      name: 'Lyric',
      component: Lyric
    },
    {
      path: '/login-in',
      name: 'LoginIn',
      component: LoginIn
    },
    {
      path: '/logisuccess',
      name: 'LogiSuccess',
      component: LogiSuccess
    },
    {
      path: '/register',
      name: 'Register',
      component: Register
    },
    {
      path: '/regisuccess',
      name: 'RegiSuccess',
      component: RegiSuccess
    },
    {
      path: '/setting',
      name: 'Setting',
      component: Setting
    },
    {
      path: '/singer-album/:id',
      name: 'SingerAlbum',
      component: SingerAlbum
    },
    {
      path: '/song-list-album/:id',
      name: 'SongListAlbum',
      component: SongListAlbum
    },
  ],

})

