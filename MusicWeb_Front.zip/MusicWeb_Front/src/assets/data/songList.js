const songStyle = [
    {name:'全部歌单'},
    {name:'流行'},
    {name:'粤语'},
    {name:'说唱'},
    {name:'摇滚'},
    {name:'纯音乐'},
    {name:'中国风'},
    {name:'乐器'},
    {name:'复古经典'}
]

export {songStyle}
